import 'package:flutter/material.dart';
import 'package:flutter_saka/widgets/bubble_story.dart';
import 'package:flutter_saka/widgets/users_post.dart';

class HomePage extends StatelessWidget {
  HomePage({Key? key});

  final List<String> users = [
    'bahaya.narkoba',
    'onik.reyyy',
    'jokowidodo',
    'kepo_lu',
    'suprakoprasi',
    'pakguruhujanhujan12',
    'agus',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Instagram',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: const [
          Icon(
            Icons.add_box_outlined,
            size: 30,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Icon(
              Icons.favorite_border,
              size: 30,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(
              Icons.send_outlined,
              size: 30,
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 120,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return BubbleStory(
                  name: users[index],
                  imageUrl:
                      'https://i.pravatar.cc/100?u=${Uri.encodeFull(users[index])}',
                );
              },
              itemCount: users.length,
            ),
          ),
          const Divider(
            height: 1,
          ),
          Expanded(
            child: ListView.builder(
              itemBuilder: (context, index) {
                return UsersPost(name: users[index]);
              },
              itemCount: users.length,
            ),
          ),
        ],
      ),
    );
  }
}
