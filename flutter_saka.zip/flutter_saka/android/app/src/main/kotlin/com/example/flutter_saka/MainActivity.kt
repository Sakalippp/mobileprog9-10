package com.example.flutter_saka

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
